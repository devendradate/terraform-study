def hello(event, context):
#def hello():
   print("Welcome to Terraform")
#hello()

